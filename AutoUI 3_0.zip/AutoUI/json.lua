-- Enhanced JSON parser
local json = {}

-- Function to determine the type of JSON structure
local function determine_type(str)
    local _, e = str:find('^%s*[%[{]')
    if e == 1 then
        if str:find('^%s*%[.*%]$') then
            return 'array'
        else
            return 'object'
        end
    end
    return 'unknown'
end

-- Function to parse JSON strings
function json.parse(json_str)
    local t = determine_type(json_str)
    if t == 'object' then
        return json._parse_object(json_str)
    elseif t == 'array' then
        return json._parse_array(json_str)
    else
        error("Invalid JSON string")
    end
end

-- Function to parse JSON objects
function json._parse_object(json_str)
    local obj = {}
    for k, v in json_str:gmatch('"(.-)"%s*:%s*(.-)[,%}]') do
        obj[k] = json._parse_value(v)
    end
    return obj
end

-- Function to parse JSON arrays
function json._parse_array(json_str)
    local arr = {}
    for v in json_str:gmatch('%s*(.-)%s*[,}]') do
        table.insert(arr, json._parse_value(v))
    end
    return arr
end

-- Function to parse individual JSON values
function json._parse_value(value)
    if value:find('^"') then
        return value:match('^"(.-)"$')
    elseif value == 'null' then
        return json.null
    elseif value == 'true' then
        return true
    elseif value == 'false' then
        return false
    elseif tonumber(value) then
        return tonumber(value)
    elseif value:find('^%[') then
        return json._parse_array(value)
    elseif value:find('^{') then
        return json._parse_object(value)
    else
        error("Invalid JSON value: " .. value)
    end
end

-- Initialize special JSON values
json.null = {}
json.not_found = function() end

return json
