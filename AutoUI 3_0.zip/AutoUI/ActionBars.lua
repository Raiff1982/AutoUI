local addon = AutoUI

function addon.SetActionBarSlot(slot, spell)
    PickupSpell(spell)
    PlaceAction(slot)
    ClearCursor()
end

function addon.SetKeyBinding(key, action)
    SetBinding(key, action)
end

function addon.SetupSlotsAndBindings(slotActions, bindings)
    for i, spell in ipairs(slotActions) do
        addon.SetActionBarSlot(i, spell)
    end

    for key, action in pairs(bindings) do
        addon.SetKeyBinding(key, action)
    end
end

function addon.SetupActionBarsAndKeybinds(classFile, specName)
    local actionBarSetup = {
        WARRIOR = {
            Arms = function()
                addon.SetupSlotsAndBindings({"Ability_Warrior_Charge", "Ability_Warrior_Rend"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Fury = function()
                addon.SetupSlotsAndBindings({"Ability_Warrior_BattleShout", "Ability_Warrior_BerserkerRage"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Protection = function()
                addon.SetupSlotsAndBindings({"Ability_Warrior_ShieldBash", "Ability_Warrior_DefensiveStance"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        PALADIN = {
            Holy = function()
                addon.SetupSlotsAndBindings({"Spell_Holy_HolyBolt", "Spell_Holy_FlashHeal"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Protection = function()
                addon.SetupSlotsAndBindings({"Spell_Holy_SealOfProtection", "Spell_Holy_SealOfRighteousness"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Retribution = function()
                addon.SetupSlotsAndBindings({"Spell_Holy_AuraOfLight", "Spell_Holy_SealOfCommand"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        HUNTER = {
            BeastMastery = function()
                addon.SetupSlotsAndBindings({"Ability_Hunter_BeastCall", "Ability_Hunter_BeastSoothe"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Marksmanship = function()
                addon.SetupSlotsAndBindings({"Ability_Hunter_AimedShot", "Ability_Hunter_HuntersMark"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Survival = function()
                addon.SetupSlotsAndBindings({"Ability_Hunter_RaptorStrike", "Ability_Hunter_SwiftStrike"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        MAGE = {
            Arcane = function()
                addon.SetupSlotsAndBindings({"Spell_Holy_MagicalSentry", "Spell_Nature_StarFall"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Fire = function()
                addon.SetupSlotsAndBindings({"Spell_Fire_FireBolt02", "Spell_Fire_FlameBolt"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Frost = function()
                addon.SetupSlotsAndBindings({"Spell_Frost_FrostBolt02", "Spell_Frost_FrostNova"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        PRIEST = {
            Discipline = function()
                addon.SetupSlotsAndBindings({"Spell_Holy_WordFortitude", "Spell_Holy_PowerWordShield"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Holy = function()
                addon.SetupSlotsAndBindings({"Spell_Holy_HolyBolt", "Spell_Holy_FlashHeal"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Shadow = function()
                addon.SetupSlotsAndBindings({"Spell_Shadow_ShadowWordPain", "Spell_Shadow_ShadowBolt"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        ROGUE = {
            Assassination = function()
                addon.SetupSlotsAndBindings({"Ability_Rogue_Eviscerate", "Ability_Rogue_SliceDice"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Outlaw = function()
                addon.SetupSlotsAndBindings({"Ability_Rogue_SinisterStrike", "Ability_Rogue_Ambush"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Subtlety = function()
                addon.SetupSlotsAndBindings({"Ability_Rogue_ShadowDance", "Ability_Rogue_Backstab"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        SHAMAN = {
            Elemental = function()
                addon.SetupSlotsAndBindings({"Spell_Nature_Lightning", "Spell_Nature_ChainLightning"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Enhancement = function()
                addon.SetupSlotsAndBindings({"Spell_Nature_LightningShield", "Spell_Nature_LightningBolt"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Restoration = function()
                addon.SetupSlotsAndBindings({"Spell_Nature_MagicImmunity", "Spell_Nature_HealingWaveGreater"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        WARLOCK = {
            Affliction = function()
                addon.SetupSlotsAndBindings({"Spell_Shadow_DeathCoil", "Spell_Shadow_Haunting"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Demonology = function()
                addon.SetupSlotsAndBindings({"Spell_Shadow_SummonFelguard", "Spell_Shadow_Metamorphosis"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Destruction = function()
                addon.SetupSlotsAndBindings({"Spell_Fire_Incinerate", "Spell_Fire_ChaosBolt"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        DRUID = {
            Balance = function()
                addon.SetupSlotsAndBindings({"Spell_Nature_StarFall", "Spell_Nature_Moonfire"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Feral = function()
                addon.SetupSlotsAndBindings({"Ability_Druid_CatForm", "Ability_Druid_Rake"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Guardian = function()
                addon.SetupSlotsAndBindings({"Ability_Racial_BearForm", "Ability_Druid_Maul"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Restoration = function()
                addon.SetupSlotsAndBindings({"Spell_Nature_HealingTouch", "Spell_Nature_Rejuvenation"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        DEATHKNIGHT = {
            Blood = function()
                addon.SetupSlotsAndBindings({"Spell_Deathknight_BloodPresence", "Spell_Deathknight_DeathStrike"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Frost = function()
                addon.SetupSlotsAndBindings({"Spell_Deathknight_FrostPresence", "Spell_Deathknight_FrostStrike"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Unholy = function()
                addon.SetupSlotsAndBindings({"Spell_Deathknight_UnholyPresence", "Spell_Deathknight_ScourgeStrike"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        MONK = {
            Brewmaster = function()
                addon.SetupSlotsAndBindings({"Spell_Monk_Brewmaster_Stance", "Spell_Monk_Brewmaster_Ability"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Mistweaver = function()
                addon.SetupSlotsAndBindings({"Spell_Monk_Mistweaver_Stance", "Spell_Monk_Mistweaver_Ability"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Windwalker = function()
                addon.SetupSlotsAndBindings({"Spell_Monk_Windwalker_Stance", "Spell_Monk_Windwalker_Ability"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        DEMONHUNTER = {
            Havoc = function()
                addon.SetupSlotsAndBindings({"Ability_DemonHunter_Havoc", "Ability_DemonHunter_EyeBeam"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Vengeance = function()
                addon.SetupSlotsAndBindings({"Ability_DemonHunter_Vengeance", "Ability_DemonHunter_SoulCleave"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        },
        EVOKER = {
            Devastation = function()
                addon.SetupSlotsAndBindings({"Ability_Evoker_Devastation", "Ability_Evoker_FireBreath"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end,
            Preservation = function()
                addon.SetupSlotsAndBindings({"Ability_Evoker_Preservation", "Ability_Evoker_EmeraldBlossom"}, {["1"] = "ACTIONBUTTON1", ["2"] = "ACTIONBUTTON2"})
            end
        }
    }

    if actionBarSetup[classFile] and actionBarSetup[classFile][specName] then
        actionBarSetup[classFile]specName
    else
        print("Error: Invalid class or spec - " .. classFile .. " " .. specName)
    end
end

-- Example usage
addon.SetupActionBarsAndKeybinds("PALADIN", "Holy")
addon.SetupActionBarsAndKeybinds("HUNTER", "BeastMastery")
