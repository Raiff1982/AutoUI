AutoUI = {}
local addon = AutoUI

-- Include a simple JSON parser
function json_parse(str)
    local json = {}
    json.null = {}
    json.not_found = function() end
    json._type = function(str)
        local _, e = str:find('^%s*[%[{}]')
        if e == 1 then return 'list' elseif str:find('^%s*%[.*%]$') then return 'array' else return 'object' end
    end
    json.parse = function(json_str)
        local t = json._type(json_str)
        if t == 'object' then return json._parse_object(json_str) elseif t == 'array' then return json._parse_array(json_str) else return json.null end
    end
    json._parse_object = function(json_str)
        local obj = {}
        for k, v in json_str:gmatch('"(.-)"%s*:%s*"(.-)"') do
            obj[k] = v
        end
        return obj
    end
    json._parse_array = function(json_str)
        local arr = {}
        for v in json_str:gmatch('"([^"]-)"') do
            table.insert(arr, v)
        end
        return arr
    end
    return json.parse(str)
end

-- Create the frame and register events
addon.frame = CreateFrame("Frame")
addon.frame:RegisterEvent("PLAYER_ENTERING_WORLD")
addon.frame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
addon.frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
addon.frame:RegisterEvent("PLAYER_LEVEL_UP")

-- Function to load the config
local function LoadConfig()
    local content = [[
        {
            "version": "3.0",
            "project": {
                "name": "AutoUI",
                "author": "Your Name",
                "description": "Configuration for AutoUI project"
            },
            "classes": {
                "WARRIOR": {
                    "Arms": "CreateArmsWarriorUI",
                    "Fury": "CreateFuryWarriorUI",
                    "Protection": "CreateProtectionWarriorUI"
                },
                "PALADIN": {
                    "Holy": "CreateHolyPaladinUI",
                    "Protection": "CreateProtectionPaladinUI",
                    "Retribution": "CreateRetributionPaladinUI"
                },
                "HUNTER": {
                    "Beast Mastery": "CreateBeastMasteryHunterUI",
                    "Marksmanship": "CreateMarksmanshipHunterUI",
                    "Survival": "CreateSurvivalHunterUI"
                },
                "ROGUE": {
                    "Assassination": "CreateAssassinationRogueUI",
                    "Outlaw": "CreateOutlawRogueUI",
                    "Subtlety": "CreateSubtletyRogueUI"
                },
                "PRIEST": {
                    "Discipline": "CreateDisciplinePriestUI",
                    "Holy": "CreateHolyPriestUI",
                    "Shadow": "CreateShadowPriestUI"
                },
                "DEATHKNIGHT": {
                    "Blood": "CreateBloodDeathKnightUI",
                    "Frost": "CreateFrostDeathKnightUI",
                    "Unholy": "CreateUnholyDeathKnightUI"
                },
                "SHAMAN": {
                    "Elemental": "CreateElementalShamanUI",
                    "Enhancement": "CreateEnhancementShamanUI",
                    "Restoration": "CreateRestorationShamanUI"
                },
                "MAGE": {
                    "Arcane": "CreateArcaneMageUI",
                    "Fire": "CreateFireMageUI",
                    "Frost": "CreateFrostMageUI"
                },
                "WARLOCK": {
                    "Affliction": "CreateAfflictionWarlockUI",
                    "Demonology": "CreateDemonologyWarlockUI",
                    "Destruction": "CreateDestructionWarlockUI"
                },
                "DRUID": {
                    "Balance": "CreateBalanceDruidUI",
                    "Feral": "CreateFeralDruidUI",
                    "Guardian": "CreateGuardianDruidUI",
                    "Restoration": "CreateRestorationDruidUI"
                },
                "MONK": {
                    "Brewmaster": "CreateBrewmasterMonkUI",
                    "Mistweaver": "CreateMistweaverMonkUI",
                    "Windwalker": "CreateWindwalkerMonkUI"
                },
                "DEMONHUNTER": {
                    "Havoc": "CreateHavocDemonHunterUI",
                    "Vengeance": "CreateVengeanceDemonHunterUI"
                },
                "EVOKER": {
                    "Devastation": "CreateDevastationEvokerUI",
                    "Preservation": "CreatePreservationEvokerUI"
                }
            },
            "settings": {
                "scaling": true,
                "defaultUI": "CreateDefaultUI"
            }
        }
    ]]
    return json_parse(content)
end

local config = LoadConfig()
if not config then return end

-- Event handler
local function OnEvent(self, event, ...)
    if event == "PLAYER_ENTERING_WORLD" then
        addon.SetupUIForClassAndSpec()
    elseif event == "PLAYER_LEVEL_UP" then
        local level = ...
        addon.ScaleUIBasedOnLevel(level)
    end
end

addon.frame:SetScript("OnEvent", OnEvent)
