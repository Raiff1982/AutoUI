-- Configuration table
local classSpecConfig = {
    Paladin = {"Holy", "Protection", "Retribution"},
    Hunter = {"Beast Mastery", "Marksmanship", "Survival"},
    Rogue = {"Assassination", "Outlaw", "Subtlety"},
    Priest = {"Discipline", "Holy", "Shadow"},
    DeathKnight = {"Blood", "Frost", "Unholy"},
    Shaman = {"Elemental", "Enhancement", "Restoration"},
    Mage = {"Arcane", "Fire", "Frost"},
    Warlock = {"Affliction", "Demonology", "Destruction"},
    Druid = {"Balance", "Feral", "Guardian", "Restoration"},
    Monk = {"Brewmaster", "Mistweaver", "Windwalker"},
    DemonHunter = {"Havoc", "Vengeance"},
    Evoker = {"Devastation", "Preservation"}
}

-- Factory function
function CreateClassSpecUI(class, spec)
    print("Setting up " .. spec .. " " .. class .. " UI")
    -- Add UI elements specific to the class and spec
end

-- Iterate over the configuration table to create UIs
for class, specs in pairs(classSpecConfig) do
    for _, spec in ipairs(specs) do
        CreateClassSpecUI(class, spec)
    end
end
