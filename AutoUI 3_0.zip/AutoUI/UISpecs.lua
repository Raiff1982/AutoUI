-- Enhanced JSON parser
local json = {}

-- Function to determine the type of JSON structure
local function determine_type(str)
    local _, e = str:find('^%s*[%[{]')
    if e == 1 then
        if str:find('^%s*%[.*%]$') then
            return 'array'
        else
            return 'object'
        end
    end
    return 'unknown'
end

-- Function to parse JSON strings
function json_parse(str)
    local json = {}
    json.null = {}
    json.not_found = function() end

    local function parse(json_str)
        local t = determine_type(json_str)
        if t == 'object' then
            return parse_object(json_str)
        elseif t == 'array' then
            return parse_array(json_str)
        else
            error("Invalid JSON string")
        end
    end

    local function parse_object(json_str)
        local obj = {}
        for k, v in json_str:gmatch('"(.-)"%s*:%s*(.-)[,%}]') do
            obj[k] = parse_value(v)
        end
        return obj
    end

    local function parse_array(json_str)
        local arr = {}
        for v in json_str:gmatch('%s*(.-)%s*[,}]') do
            table.insert(arr, parse_value(v))
        end
        return arr
    end

    local function parse_value(value)
        if value:find('^"') then
            return value:match('^"(.-)"$')
        elseif value == 'null' then
            return json.null
        elseif value == 'true' then
            return true
        elseif value == 'false' then
            return false
        elseif tonumber(value) then
            return tonumber(value)
        elseif value:find('^%[') then
            return parse_array(value)
        elseif value:find('^{') then
            return parse_object(value)
        else
            error("Invalid JSON value: " .. value)
        end
    end

    return parse(str)
end

-- Function to create UI from configuration
function CreateUIFromConfig(config)
    for class, specs in pairs(config.classes) do
        for spec, func_name in pairs(specs) do
            if _G[func_name] then
                _Gfunc_name
            else
                print("Function " .. func_name .. " not found for " .. class .. " - " .. spec)
            end
        end
    end
end

-- Example JSON configuration
local json_str = [[
{
  "version": "3.0",
  "project": {
    "name": "AutoUI",
    "author": "Your Name",
    "description": "Configuration for AutoUI project"
  },
  "classes": {
    "WARRIOR": {
      "Arms": "CreateArmsWarriorUI",
      "Fury": "CreateFuryWarriorUI",
      "Protection": "CreateProtectionWarriorUI"
    },
    "PALADIN": {
      "Holy": "CreateHolyPaladinUI",
      "Protection": "CreateProtectionPaladinUI",
      "Retribution": "CreateRetributionPaladinUI"
    },
    "HUNTER": {
      "Beast Mastery": "CreateBeastMasteryHunterUI",
      "Marksmanship": "CreateMarksmanshipHunterUI",
      "Survival": "CreateSurvivalHunterUI"
    },
    "ROGUE": {
      "Assassination": "CreateAssassinationRogueUI",
      "Outlaw": "CreateOutlawRogueUI",
      "Subtlety": "CreateSubtletyRogueUI"
    },
    "PRIEST": {
      "Discipline": "CreateDisciplinePriestUI",
      "Holy": "CreateHolyPriestUI",
      "Shadow": "CreateShadowPriestUI"
    },
    "DEATHKNIGHT": {
      "Blood": "CreateBloodDeathKnightUI",
      "Frost": "CreateFrostDeathKnightUI",
      "Unholy": "CreateUnholyDeathKnightUI"
    },
    "SHAMAN": {
      "Elemental": "CreateElementalShamanUI",
      "Enhancement": "CreateEnhancementShamanUI",
      "Restoration": "CreateRestorationShamanUI"
    },
    "MAGE": {
      "Arcane": "CreateArcaneMageUI",
      "Fire": "CreateFireMageUI",
      "Frost": "CreateFrostMageUI"
    },
    "WARLOCK": {
      "Affliction": "CreateAfflictionWarlockUI",
      "Demonology": "CreateDemonologyWarlockUI",
      "Destruction": "CreateDestructionWarlockUI"
    },
    "DRUID": {
      "Balance": "CreateBalanceDruidUI",
      "Feral": "CreateFeralDruidUI",
      "Guardian": "CreateGuardianDruidUI",
      "Restoration": "CreateRestorationDruidUI"
    },
    "MONK": {
      "Brewmaster": "CreateBrewmasterMonkUI",
      "Mistweaver": "CreateMistweaverMonkUI",
      "Windwalker": "CreateWindwalkerMonkUI"
    },
    "DEMONHUNTER": {
      "Havoc": "CreateHavocDemonHunterUI",
      "Vengeance": "CreateVengeanceDemonHunterUI"
    },
    "EVOKER": {
      "Devastation": "CreateDevastationEvokerUI",
      "Preservation": "CreatePreservationEvokerUI"
    }
  },
  "settings": {
    "scaling": true,
    "defaultUI": "CreateDefaultUI"
  }
}
]]

-- Parse and create UI from the example JSON configuration
local parsed_json = json_parse(json_str)
if parsed_json then
    CreateUIFromConfig(parsed_json)
else
    print("Failed to parse JSON.")
end
